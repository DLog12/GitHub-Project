//Logan Deegan 10/23/2023 2:00PM 
//Lab Assignment Seven
//allmost each custom function uses the custom function drawCube only function that doesnt use this function is calculate cube volume

var l;  //length
var h;  //height
var w;  //width
var s;  //scale
var r;  //rotate
var x;  //x position
var y;  //y position

function setup() 
{
  createCanvas(400, 400);
}

function draw() 
{
  background(220);
  //setting angleMode to Degrees
  angleMode(DEGREES);
  
  //setting all the vars
  l = 10;
  h = 10;
  w = 3;
  s = 2;
  r = 20;
  x = 100;
  y = 50;
  
  //call the doFunctions function
  doFunctions();
}

//Draws a cube using 4 lines 
function drawCube(l,h,w)
{
  line(l,h,l,h*w);
  line(l,h,l*w,h);
  line(l,h*w,l*w,h*w);
  line(l*w,h*w,l*w,h);
}

//loops the a for loop and creates a a cube from the drawCube function and translates the position of x and y = to the current i var
function cubeLoop(l,h,w)
{
  for(var i = 0; i <= 10; i++)
  {
    translate(i + 2 ,i + 2);
    drawCube(l,h,w);
  }
}

//translate the drawCube x,y based of the inputed x,y vars
function translateCube(x,y,l,h,w)
{
  translate(x,y);
  drawCube(l,h,w);
}

//scales the drawCube based off the var s
function scaleCube(s,l,h,w)
{
  scale(s);
  drawCube(l,h,w);
}

//rotates the drawCube angle by r
function rotateCube(r,l,h,w)
{
  rotate(r);
  drawCube(l,h,w);
}

//Input a length and height will print the Volume 
function calculateCubeVolume(l,h,w)
{
  var Volume = l * h * w;
  print(Volume);
}

//A function that calls all the other functions
function doFunctions()
{
  push()
  translate(100,20)
  drawCube(l,h,w);
  pop()
  push();
  translateCube(x,y,l,h,w);
  pop()
  push()
  cubeLoop(l,h,w);
  pop();
  push();
  translate(200,300);
  scaleCube(s,l,h,w);
  pop();
  translate(200,200);
  rotateCube(r,l,h,w);
  calculateCubeVolume(l,h,w);
}