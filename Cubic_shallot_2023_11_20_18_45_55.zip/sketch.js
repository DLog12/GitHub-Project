var joystick;
var squareX = 200; // Initial x-coordinate of the square
var squareY = 200; // Initial y-coordinate of the square

function setup() {
  createCanvas(400, 400);

  joystick = createJoystick();
  if (!joystick.calibrated())
    joystick.calibrate(false);
  joystick.onButtonPressed(createCube);
  joystick.onButtonReleased(onJoystick);
  joystick.onAxesPressed(onJoystick);
  joystick.onAxesReleased(onJoystick);
}

function draw() 
{
  background(220);
  square(300,100,55)
  squareX += joystick.getAxesValueByIndex(0, 0) * 5; 
  squareY += joystick.getAxesValueByIndex(0, 1) * 5;
  
  createSquare(squareX, squareY);
}

function onJoystick(e) {

}

function createSquare(x, y) 
{
  square(x, y, 50);
}
function createCube(e) {
  if (e.index === 0 && e.pressed) 
  {
    square(30, 20, 55);
  }
}