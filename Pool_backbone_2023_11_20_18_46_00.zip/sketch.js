let image1, image2, transparentImage;
let myFont;

function preload() 
{
  image1 = loadImage('images/Slime.gif');
  image2 = loadImage('images/heart.png');
  transparentImage = loadImage('images/Circle.png');
  myFont = loadFont('images/helvetica.ttf');
}

function setup() 
{
  let canvas = createCanvas(400, 400);
  canvas.parent('myCanvas');
  textFont(myFont);
}

function draw() 
{
  background("white");

  //Use mouseX/mouseY to change image location/size
  let img1Size = map(mouseX, 0, width, 50, 200);
  image(image1, mouseX, mouseY, img1Size, img1Size);

  //Use mouseX/mouseY to change image location
  image(image2, mouseX + 100, mouseY, 100, 100);

  //Use the text function
  textSize(32)
  fill('red');
  stroke(0);
  text("Hello Heart", 50, 50);

  //Change stroke and fill for the text
  fill('green');
  stroke(255);
  text("Hello Slime", 50, 100);

  //Create text with width and height measurements
  fill('blue');
  noStroke();
  text("Hello Tree", 50, 200, 400, 400);

  //Use mouseX/mouseY to change transparent image location
  image(transparentImage, mouseX, mouseY + 100, 100, 100);
}